// const API_KEY = process.env.REACT_APP_TMDB_KEY;   // .env에 있는 키 가져오기
// const BASE_URL = "https://api.themoviedb.org/3";

// export async function testFetchPopular() {
//   const res = await fetch(`${BASE_URL}/movie/popular?api_key=${API_KEY}&language=ko-KR`);
//   const data = await res.json();
//   console.log("TMDB 응답:", data);      // 결과 확인
//   return data;
// }
